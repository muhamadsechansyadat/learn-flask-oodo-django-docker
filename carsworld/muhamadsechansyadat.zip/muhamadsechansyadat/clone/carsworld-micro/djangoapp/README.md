# 02-django-single-app

Django blog sebagai penyedia data via DRF (atau juga nanti ditambahkan view-nya)
## Steps
