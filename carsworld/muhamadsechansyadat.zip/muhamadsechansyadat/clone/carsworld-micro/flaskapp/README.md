# Flask SingleApp Blog Client

Flask disini bertindak sebagai client/viewer dari blog yang akan disatukan dengan aplikasi skala besar microservices

## Command
```
# Menjalankan server development dengan debug enabled
set FLASK_ENV=dev
python manage.py runserver -d
```